/**
 * 
 */
package com.start.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.start.entities.AdminUser;
import com.start.entities.CustomUser;

/**
 * @author ~ayodh_verma
 *
 */

@Repository
public class AdminRepository {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	// To save admin into the database...
		public boolean createAdmin(AdminUser admin) {
			Session session = sessionFactory.getCurrentSession();
			session.persist(admin);
			return true;
		}
	
	// To get user by email...
		public boolean validateMail(String adminEmail) { 
		  TypedQuery<AdminUser> getAdminByEmail = entityManager.createQuery("SELECT u FROM AdminUser u WHERE u.email =:email",AdminUser.class); 
		  getAdminByEmail.setParameter("email", adminEmail); 
		  List<AdminUser> user =getAdminByEmail.getResultList();
		  System.out.println(user);
		  boolean flag = false;
		  
		  if(!user.isEmpty()) { 
			  flag = true;
			  System.out.println(flag);
		  } 
		  System.out.println(flag);
		  return flag; 
		  }
}
