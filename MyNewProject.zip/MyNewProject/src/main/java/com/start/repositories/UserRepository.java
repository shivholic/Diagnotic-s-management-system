/**
 * 
 */
package com.start.repositories;

import java.util.List;
import java.util.Objects;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContexts;
import javax.persistence.TypedQuery;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.start.dtos.UserDTO;
import com.start.entities.CustomUser;

/**
 * @author ~ayodh_verma
 *
 */

@Repository
@Transactional
public class UserRepository {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	// To save user into the database...
	
	public boolean createUser(CustomUser user) {
		
		Session session = sessionFactory.getCurrentSession();
		session.persist(user);
		return true;
	}
	
	// To get user by email...
	
	
	  public boolean validateMail(String userEmail) {
	  
	  //Session session = sessionFactory.getCurrentSession(); 
	  TypedQuery<CustomUser> getUserByEmail = entityManager.createQuery("SELECT u FROM CustomUser u WHERE u.email =:email",CustomUser.class); 
	  getUserByEmail.setParameter("email", userEmail); 
	  List<CustomUser> user =getUserByEmail.getResultList();
	  System.out.println(user);
	  boolean flag = false;
	  
	  if(!user.isEmpty()) { 
		  flag = true;
		  System.out.println(flag);
	  } 
	  System.out.println(flag);
	  return flag; 
	  }
	 
}
