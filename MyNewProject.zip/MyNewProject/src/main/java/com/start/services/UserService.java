/**
 * 
 */
package com.start.services;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.start.dtos.UserDTO;
import com.start.entities.CustomUser;
import com.start.repositories.UserRepository;
import com.start.utils.UserAndAdminMappings;


/**
 * @author ~ayodh_verma
 *
 */

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private UserAndAdminMappings userAndAdminMappings;
	
	@Transactional
	public boolean createUser(UserDTO userRequestData) {
		CustomUser user = new CustomUser();
		
		  if(this.userRepository.validateMail(userRequestData.getEmail())) { 
			  System.out.println("Condition true");
			  return false; 
		  }
		 
		userAndAdminMappings.mapUserDTOToUserEntity(userRequestData, user);
		return this.userRepository.createUser(user);
	}
}
