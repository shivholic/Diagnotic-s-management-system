/**
 * 
 */
package com.start.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.start.dtos.AdminDTO;
import com.start.entities.AdminUser;
import com.start.repositories.AdminRepository;
import com.start.utils.UserAndAdminMappings;

/**
 * @author ~ayodh_verma
 *
 */

@Service
public class AdminService {
	
	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired
	private UserAndAdminMappings userAndAdminMappings;
	
	public boolean createAdmin(AdminDTO userRequestData) {
		AdminUser adminUser = new AdminUser();
		if(this.adminRepository.validateMail(adminUser.getEmail())) {
			System.out.println("condition true");
			return false;
		}
		return this.adminRepository.createAdmin(adminUser);
	}
}
