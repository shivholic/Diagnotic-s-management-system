/**
 * 
 */
package com.start.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.start.dtos.AdminDTO;
import com.start.services.AdminService;

/**
 * @author ~ayodh_verma
 *
 */

@Controller
@RequestMapping(value = "/admin")
public class AdminController {
	
	@Autowired
	AdminService adminService;
	
	// To register Admin...
		@RequestMapping(value = "/registerAdmin", method = RequestMethod.GET)
		public ModelAndView registerAdmin(HttpServletRequest request, HttpServletResponse response) {
			ModelAndView view = new ModelAndView();
			view.addObject("adminUser", new AdminDTO());
			view.setViewName("registerAdmin");
			return view;
		}
		
	// To create Admin...
		@RequestMapping(value = "/createAdmin", method = RequestMethod.POST)
		public ModelAndView createAdmin(@ModelAttribute AdminDTO adminRequestData, HttpSession session) {
			ModelAndView view = new ModelAndView();
			if(this.adminService.createAdmin(adminRequestData)) {
				
			}
			return view;
		}
}
