/**
 * 
 */
package com.start.utils;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.start.dtos.AdminDTO;
import com.start.dtos.UserDTO;
import com.start.entities.AdminUser;
import com.start.entities.CustomUser;

/**
 * @author ~ayodh_verma
 *
 */

@Component
public class UserAndAdminMappings {
	
	@Value("${profile_image_upload_path}")
	private String profileImageUploadPath;
	
	@Value("${default_profile_image_name}")
	private String defaultProfileImageName;
	
	// Mapping UserDTO to UserEntity...
		public void mapUserDTOToUserEntity(UserDTO userDTO, CustomUser userEntity) {
			userEntity.setName(userDTO.getName());
			userEntity.setPhone(userDTO.getPhone());
			userEntity.setBirthDate(userDTO.getBirthDate());
			userEntity.setGender(userDTO.getGender());
			userEntity.setEmail(userDTO.getEmail());
			userEntity.setPassword(userDTO.getPassword());
			
			if(Objects.nonNull(userDTO.getProfileImage()) && !userDTO.getProfileImage().isEmpty()) {
				// Find extension of uploaded file as....
				String extension = FilenameUtils.getExtension(userDTO.getProfileImage().getOriginalFilename());
				String fileName = this.generateUniqueFileName(extension);
				this.saveProfileImage(userDTO.getProfileImage(), fileName);
			}
		}
	
	// Mapping AdminDTO to AdminEntity...
		public void mapAdminDTOTOAdminEntity(AdminDTO adminDTO, AdminUser adminEntity) {
			adminEntity.setName(adminDTO.getName());
			adminEntity.setPhone(adminDTO.getPhone());
			adminEntity.setBirthDate(adminDTO.getBirthDate());
			adminEntity.setGender(adminDTO.getGender());
			adminEntity.setEmail(adminDTO.getEmail());
			adminEntity.setPassword(adminDTO.getPassword());
			
			if(Objects.nonNull(adminDTO.getProfileImage()) && !adminDTO.getProfileImage().isEmpty()) {
				// Find extension of uploaded file as....
				String extension = FilenameUtils.getExtension(adminDTO.getProfileImage().getOriginalFilename());
				String fileName = this.generateUniqueFileName(extension);
				this.saveProfileImage(adminDTO.getProfileImage(), fileName);
			}
		}
		
	// To Generate unique file name...	
		public String generateUniqueFileName(String extension) {
			
			String fileName = "user_profile_"+System.currentTimeMillis()+"."+extension;
			return fileName;
		}
		
	// To save image in memory...
		public void saveProfileImage(MultipartFile file, String fileName) {
			
			try {
				Path root = Paths.get(this.profileImageUploadPath);
				Files.copy(file.getInputStream(), root.resolve(fileName));
			} catch (Exception e) {
				throw new RuntimeException("Could not store the file. Error: " + e.getMessage());
			} 
		}
}
